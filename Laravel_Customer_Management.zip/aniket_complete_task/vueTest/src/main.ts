import { createApp } from 'vue';
import App from './App.vue';
import { registerPlugins } from '@/plugins';
import { createAppStore } from './vuex/storeVue';
import vuetify from './plugins/vuetify' 

import 'bootstrap/dist/css/bootstrap.min.css';
import 'unfonts.css';

const app = createApp(App);
const store = createAppStore();  

app.use(store);   
app.use(vuetify)               
registerPlugins(app);

app.mount('#app');
