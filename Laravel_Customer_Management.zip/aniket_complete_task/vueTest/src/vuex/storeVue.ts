import { createStore } from 'vuex';
import { useRouter } from 'vue-router'
const router = useRouter()

export function createAppStore() {
  return createStore({
    state: {
      count: 10,
      user: JSON.parse(localStorage.getItem('user') || 'null'),
      appTitle: 'Home',
      sidebar: false,
      storedUser: !!localStorage.getItem('user'),
      menuItems: [
        { title: 'Home', path: '/', icon: 'mdi-home' },
        { title: 'Design', path: '/design', icon: 'mdi-car' },
        { title: 'Sign In', path: '/logIn', icon: 'mdi-lock-open' },
        { title: 'Customers', path: '/customer', icon: 'mdi-account-group', requiresAuth: true },
        { title: 'Log Out', path: '/logout', icon: 'mdi-lock-open', requiresAuth: true },
      ]
    },
    mutations: {
      logOutFromStore(state) {
        state.user = null;
        state.storedUser = false;

      },
      logInFromStore(state,user) {
        state.user = user;
        state.storedUser = true;
      }
    },
    getters: {
      hasAdd(state) {
        if (state.user && state.user.token) {
          return state.menuItems.filter(item => item.title !== 'Sign In');
        }
        return state.menuItems.filter(item => !item.requiresAuth);
      }
    }
  });
}
