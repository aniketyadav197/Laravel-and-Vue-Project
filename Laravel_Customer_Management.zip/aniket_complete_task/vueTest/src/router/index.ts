import { createRouter, createWebHistory } from 'vue-router'
import HelloWorld from '@/components/HelloWorld.vue' 
import Design from '@/components/Design.vue'
import Navbar from '@/components/Navbar.vue'
import Registration from '@/components/Registration.vue'
import LogOut from '@/components/LogOut.vue'
import CustomerForm from '@/components/CustomerForm.vue'
import CustomerDetail from '@/components/CustomerDetail.vue'
import CustomerList from '@/components/CustomerList.vue'
import LogIn from '@/components/LogIn.vue'

const routes = [
  {
    path: '/',
    name: 'HelloWorld',
    component: HelloWorld
  },
  {
    path: '/navbar',
    name: 'Navbar',
    component: Navbar
  },
  {
    path: '/register',
    name: 'Register',
    component: Registration
  },

  {
    path: '/customer',
    name: 'Customers',
    component: CustomerList
  },
  {
    path: '/logout',
    name: 'LogOut',
    component: LogOut
  },
    {
    path: '/customerForm',
    name: 'CustomerForm',
    component: CustomerForm
  },
  {
    path: '/design',
    name: 'Design',
    component: Design
  },
  {
  path: '/customerDetails/:id',
  name: 'CustomerDetail',
  component: CustomerDetail
},
  {
  path: '/logIn/',
  name: 'LogIn',
  component: LogIn
}
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router
