<template>
  <div class="logout-container">
    <div class="loader"></div>
    <p>Logging you out, please wait…</p>

    <div class="modal fade show" style="display: block;" v-if="showDialog">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-danger text-white">
            <h5 class="modal-title">Server Error</h5>
          </div>
          <div class="modal-body">
            <p>Something went wrong. Please try again later.</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapMutations } from 'vuex';
import axiosClient from '@/axios/axiosClient';

export default {
  name: 'LogOut',
  data() {
    return {
      showDialog: false
    };
  },
  methods: {
    ...mapMutations(['logOutFromStore'])
  },
  async mounted() {
    const storedUser = JSON.parse(localStorage.getItem('user'));

    if (storedUser && storedUser.token) {
      try {
        await axiosClient.post("logout");
        localStorage.removeItem('user');
        this.logOutFromStore();
        this.$router.push('/logIn');
      } catch (error) {
        if (error.response && error.response.status === 500) {
          this.showDialog = true;

          setTimeout(() => {
            this.showDialog = false;
            this.$router.push('/design');
          }, 3000);
        } else {
          this.logOutFromStore();
          const visibleMenuItems = this.$store.getters.hasAdd;
        }
      }
    } else {
      this.logOutFromStore();
    }
  }
};
</script>

<style scoped>
.logout-container {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100vh;
  position: relative;
  z-index: 0;
}

.loader {
  border: 8px solid #f3f3f3;
  border-top: 8px solid #007bff;
  border-radius: 50%;
  width: 60px;
  height: 60px;
  animation: spin 1s linear infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

</style>
