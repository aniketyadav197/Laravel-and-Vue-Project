<template>
  <div class="container mt-2">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow card_body">
          <div class="card-body">
            <div class="login_logo_div">
                          <img class="login_logo" src="../assets/pics/login_logo_pic.avif"></img>

            </div>
            <h1 class="card-title text-center mb-4 animated-heading">Login</h1>

            <div v-if="showSuccessDialog" class="alert alert-success text-center py-2">
              ✅ Logged in successfully!
            </div>
            <div v-if="showErrorDialog" class="alert alert-danger text-center py-2">
               {{ errorMessage }}
            </div>
            <form @submit.prevent="handleLogin">
              <div class="mb-3">
                <label for="logEmail" class="form-label">Email</label>
                <input type="email" id="logEmail" class="form-control" v-model="logEmail" required />
              </div>
              <div class="mb-3">
                <label for="logPassword" class="form-label">Password</label>
                <input type="password" id="logPassword" class="form-control" v-model="logPassword" required />
              </div>
              <button type="submit" class="btn btn-primary w-100">Log In</button>

              <div class="mt-2 text-center">
                Not Registered? <router-link to="/register">Register</router-link>
              </div>
            </form>

          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'
import { useStore } from 'vuex'
import { useRouter } from 'vue-router'

const store = useStore()
const router = useRouter()

const logEmail = ref('')
const logPassword = ref('')
const showSuccessDialog = ref(false)
const showErrorDialog = ref(false)
const errorMessage = ref('')

const handleLogin = async () => {
  if (logEmail.value && logPassword.value) {
    try {
      const response = await axios.post('http://127.0.0.1:8000/api/login', {
        email: logEmail.value,
        password: logPassword.value
      })

      const user_login_token = response.data.access_token
      const user_details = { token: user_login_token }

      localStorage.setItem('user', JSON.stringify(user_details))
      store.commit('logInFromStore', user_details)

      showSuccessDialog.value = true
      showErrorDialog.value = false

      setTimeout(() => {
        router.push('/design')
      }, 300)

    } catch (error) {
      if (error.response && error.response.status === 401) {
        showErrorDialog.value = true
        showSuccessDialog.value = false
        errorMessage.value = 'Incorrect email or password.'

        setTimeout(() => {
          showErrorDialog.value = false
        }, 3000)
      } 
       else if (error.response.status === 500) {
         showErrorDialog.value = true
        setTimeout(() => {
          showErrorDialog.value = false
        }, 3000)
        errorMessage.value = ' Server error. Please try again later.'
      }
      
      else {
        console.error('An error occurred:', error)
      }
    }
  } else {
    showErrorDialog.value = true
    setTimeout(() => {
      showErrorDialog.value = false
    }, 3000)
  }
}
</script>

<style scoped>
.animated-heading {
  animation: fadeInDown 0.6s ease;
}

@keyframes fadeInDown {
  from {
    opacity: 0;
    transform: translateY(-10px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.card_body {
  border-radius: 10px;
  padding: 20px;
}

.alert {
  font-size: 0.95rem;
}
.login_logo{
      padding: 20px;
    margin: 5px;
    width: 150px;
    height: 150px;
    border-radius: 50%;
    text-align: center;
}
.login_logo_div{
  text-align: center;
}
</style>
