<template>
  <div class="container">
    <form @submit.prevent="submitForm">
      <h2>Customer Form</h2>
      <div class="mb-3">
        <label class="form-label mt-2">Name *</label>
        <input
          type="text"
          class="form-control"
          v-model="customer.name"
          :class="{ 'is-invalid': errors.name }"
        />
        <div v-if="errors.name" class="text-danger">{{ errors.name }}</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Company *</label>
        <input
          type="text"
          class="form-control"
          v-model="customer.company"
          :class="{ 'is-invalid': errors.company }"
        />
        <div v-if="errors.company" class="text-danger">{{ errors.company }}</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Email *</label>
        <input
          type="email"
          class="form-control"
          v-model="customer.email"
          :class="{ 'is-invalid': errors.email }"
        />
        <div v-if="errors.email" class="text-danger">{{ errors.email }}</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Phone *</label>
        <input
          type="text"
          class="form-control"
          v-model="customer.phone"
          :class="{ 'is-invalid': errors.phone }"
        />
        <div v-if="errors.phone" class="text-danger">{{ errors.phone }}</div>
      </div>

      <div class="mb-3">
        <label class="form-label">Address *</label>
        <textarea
          class="form-control"
          v-model="customer.address"
          :class="{ 'is-invalid': errors.address }"
        ></textarea>
        <div v-if="errors.address" class="text-danger">{{ errors.address }}</div>
      </div>

      <h5>Contact Persons</h5>
      <button type="button" class="btn btn-sm btn-outline-primary mb-3" @click="addContact">
        <i class="bi bi-plus-circle"></i> Add Contact
      </button>

      <div
        v-for="(contact, index) in customer.contacts"
        :key="index"
        class="border p-3 mb-3 rounded"
      >
        <div class="row g-2 align-items-center">
          <div class="col-12 col-md-3">
            <input
              type="text"
              class="form-control"
              placeholder="Name"
              v-model="contact.name"
              :class="{ 'is-invalid': errors.contacts[index]?.name }"
            />
            <div v-if="errors.contacts[index]?.name" class="text-danger">
              {{ errors.contacts[index].name }}
            </div>
          </div>

          <div class="col-12 col-md-3">
            <input
              type="text"
              class="form-control"
              placeholder="Designation"
              v-model="contact.designation"
            />
          </div>

          <div class="col-12 col-md-3">
            <input
              type="email"
              class="form-control"
              placeholder="Email"
              v-model="contact.email"
              :class="{ 'is-invalid': errors.contacts[index]?.email }"
            />
            <div v-if="errors.contacts[index]?.email" class="text-danger">
              {{ errors.contacts[index].email }}
            </div>
          </div>

          <div class="col-12 col-md-2">
            <input
              type="text"
              class="form-control"
              placeholder="Phone"
              v-model="contact.phone"
              :class="{ 'is-invalid': errors.contacts[index]?.phone }"
            />
            <div v-if="errors.contacts[index]?.phone" class="text-danger">
              {{ errors.contacts[index].phone }}
            </div>
          </div>

          <div class="col-12 col-md-1 d-flex align-items-center gap-2">
            <input
              type="radio"
              :name="'primaryContact'"
              :checked="contact.isPrimary"
              @change="setPrimary(index)"
            />
            <button type="button" class="btn btn-sm btn-danger" @click="removeContact(index)">
              <i class="bi bi-trash">Remove</i>
            </button>
          </div>
        </div>
      </div>
            <p v-if="error_found_in_form" class="text-danger">  {{ error_found_in_form }}</p>

      <div class="text-end">
        <button type="submit" class="btn btn-primary">Submit</button>
      </div>

    </form>
  </div>
</template>

<script setup>
import { reactive,ref } from 'vue';
import axiosClient from '@/axios/axiosClient';
import { useRouter} from 'vue-router'
const router = useRouter()

const error_found_in_form = ref(false)

const customer = reactive({
  name: '',
  company: '',
  email: '',
  phone: '',
  address: '',
  contacts: [],
});

const errors = reactive({
  name: '',
  company: '',
  email: '',
  phone: '',
  address: '',
  contacts: []
});

const addContact = () => {
  customer.contacts.push({
    name: '',
    designation: '',
    email: '',
    phone: '',
    isPrimary: false
  });
  errors.contacts.push({});
};

const removeContact = (index) => {
  customer.contacts.splice(index, 1);
  errors.contacts.splice(index, 1);
};

const setPrimary = (index) => {
  customer.contacts.forEach((c, i) => (c.isPrimary = i === index));
};

const submitForm = async () => {
  errors.name = '';
  errors.company = '';
  errors.email = '';
  errors.phone = '';
  errors.address = '';
  errors.contacts = [];

  let hasError = false;
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!customer.name.trim()) {
    errors.name = 'Customer name is required.';
    hasError = true;
  }

  if (!customer.company.trim()) {
    errors.company = 'Company is required.';
    hasError = true;
  }

  if (!customer.email.trim()) {
    errors.email = 'Customer email is required.';
    hasError = true;
  }
        if (!emailPattern.test(customer.email)) {
        errors.email = 'Please enter a valid email address.';
        hasError = true;
      }

  if (!customer.phone.trim()) {
    errors.phone = 'Customer phone is required.';
    hasError = true;
  }
  const phone = customer.phone.trim();
  if (!/^\d{5,}$/.test(phone)) {
    errors.phone = 'Customer phone must be a number with at least 5 digits.';
    hasError = true;
  }
  if (!customer.address.trim()) {
    errors.address = 'Customer address is required.';
    hasError = true;
  }

  if (customer.contacts.length === 0) {
    alert('At least one contact person is required.');
    hasError = true;
  } else {
    customer.contacts.forEach((contact, index) => {
      const contactErrors = {
        name: '',
        email: '',
        phone: ''
      };

      if (!contact.name.trim()) {
        contactErrors.name = 'Name is required.';
        hasError = true;
      }

      if (!contact.email.trim()) {
        contactErrors.email = 'Email is required.';
        hasError = true;
      }
      if (!emailPattern.test(contact.email)) {
        contactErrors.email = 'Please enter a valid email address.';
        hasError = true;
      }

  const phone = contact.phone.trim();

  if (!/^\d{5,}$/.test(phone)) {
    contactErrors.phone = 'Phone must be a number with at least 5 digits.';
    hasError = true;
  }

  errors.contacts[index] = contactErrors;
    });
  }

  if (hasError) return;

try {
  const user = JSON.parse(localStorage.getItem('user'));
  const token = user.token;

  const contactPerson = (customer.contacts || []).map((c) => ({
    name: c.name,
    email: c.email,
    mobile: c.phone,
    designation: c.designation,
    isPrimary: !!c.isPrimary
  }));

  console.log('Contact persons:', JSON.stringify(contactPerson, null, 2));

  const payload = {
    name: customer.name,
    email: customer.email,
    mobile: customer.phone,
    address: customer.address,
    company: customer.company,
    contactPerson: contactPerson
  };

  console.log('Submitting customer data:', JSON.stringify(payload, null, 2));

  const response = await axiosClient.post('/customer', payload);

  alert('Customer added successfully!');
  router.push('/customer');

} catch (error) {
  console.error('Error submitting customer:', error);
   if (error.response) {
    error_found_in_form.value = true
    const errorMessage = JSON.stringify(error.response.data, null, 2);
        error_found_in_form.value = `Error submitting customer:\n${errorMessage}`;
  } else {
    alert('An unexpected error occurred. Please try again.');
  }
}

};
</script>

<style scoped>
input[type='radio'] {
  margin-right: 4px;
}
.text-danger {
  font-size: 0.875rem;
}
.is-invalid {
  border-color: #dc3545;
}
</style>
