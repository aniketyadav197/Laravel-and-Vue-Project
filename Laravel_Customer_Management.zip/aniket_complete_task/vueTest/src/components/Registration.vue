<template>
  <div class="container mt-2">
    <div class="row justify-content-center">
      <div class="col-md-6 col-lg-5">
        <div class="card shadow card_body">
          <div class="card-body">
            <h1 class="card-title text-center mb-4 animated-heading">Users Registration</h1>

            <form @submit.prevent="registerUser" :class="{ blurred: dialog}">
              <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" id="name" class="form-control" v-model="name" />
              </div>
              <div class="mb-3">
                <label for="regEmail" class="form-label">Email</label>
                <input type="email" id="regEmail" class="form-control" v-model="regEmail" />
              </div>
              <div class="mb-3">
                <label for="regPassword" class="form-label">Password</label>
                <input type="password" id="regPassword" class="form-control" v-model="regPassword" />
              </div>
              <div class="mb-3">
                <label for="password_confirmation" class="form-label">Confirm Password</label>
                <input type="password" id="password_confirmation" class="form-control" v-model="password_confirmation" />
              </div>
              <button type="submit" class="btn btn-primary w-100 fade-in-pink">Register</button>

              <div class="mt-2 text-center">
                Already Registered?
                <a href="/logIn">Log In</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import axios from 'axios'
import { useStore } from 'vuex'
import { useRoute,useRouter } from 'vue-router';

const router = useRouter()

const dialog = ref(false)
const name = ref('')
const regEmail = ref('')
const regPassword = ref('')
const password_confirmation = ref('')
const store = useStore()

const registerUser = async () => {
  console.log("registerUser called")
  try {
    const response = await axios.post("http://127.0.0.1:8000/api/register", {
      name: name.value,
      email: regEmail.value,
      password: regPassword.value,
      password_confirmation: password_confirmation.value,
    })
    alert("User registered successfully!")
    router.push('/logIn')

  } catch (error) {
    console.log("failed whike register")
    alert("Registration failed.");
  }
}

</script>

<style scoped>
.card_body {
  background: linear-gradient(to right, #F8BBD0, #F48FB1);
}

.fade-in-pink {
  background: linear-gradient(to right, #F06292, #F8BBD0);
  border: none;
  color: white;
  font-weight: bold;
  border-radius: 50px;
  opacity: 0;
  animation: fadeIn 1s ease-in forwards;
  transition: background 0.3s ease;
}

.fade-in-pink:hover {
  background: linear-gradient(to right, #fad0c4, #ff9a9e);
}

@keyframes fadeIn {
  to {
    opacity: 1;
  }
}

.animated-heading {
  opacity: 0;
  transform: translateY(-20px);
  animation: fadeSlideDown 1.5s ease-out forwards;
  border-radius: 50px;
  background: linear-gradient(to right, #F06292, #F8BBD0);
  padding: 3px;
  border: none;
  color: white;
}

@keyframes fadeSlideDown {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}


.blurred {
    opacity: 0.3;
}

</style>
