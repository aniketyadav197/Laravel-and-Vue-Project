<template>
  <div class="background-wrapper">
  <v-container>
    <h1>All Sections Cars</h1>
    <br/>
    <v-row>
      <v-col cols="12" sm="4">
        <v-card>
          <v-card-title>Tata Tiago</v-card-title>
          <v-card-text class="text-center">
            <v-img :src="tataTiago" alt="Tata Tiago" height="150px" cover></v-img>
          </v-card-text>
          <v-card-actions class="d-flex flex-column">
            <div id="tata_tiago" class="d-flex gap-2">
              <v-btn @click="addCarStock($event, 1)" color="primary" size="small">+1</v-btn>
              <v-btn @click="addCarStock($event, 5)" color="primary" size="small">+5</v-btn>
              <v-btn @click="addCarStock($event, -1)" color="error" size="small">-1</v-btn>
            </div>
            <p class="mt-2">Total Sold: {{ tata_tiagos }}</p>
          </v-card-actions>
        </v-card>
      </v-col>

      <v-col cols="12" sm="4">
        <v-card theme="dark">
          <v-card-title  class="text-primary-darken-1">Mini Cooper</v-card-title>
          <v-card-text class="text-center">
            <v-img :src="miniCooper" alt="Mini Cooper" height="150px" cover></v-img>
          </v-card-text>
          <v-card-actions class="d-flex flex-column">
            <div id="mini_cooper" class="d-flex gap-2">
              <v-btn @click="addCarStock($event, 1)" color="primary" size="small">+1</v-btn>
              <v-btn @click="addCarStock($event, 5)" color="primary" size="small">+5</v-btn>
              <v-btn @click="addCarStock($event, -1)" color="error" size="small">-1</v-btn>
            </div>
            <p class="mt-2">Total Sold: {{ mini_cooper }}</p>
          </v-card-actions>
        </v-card>
      </v-col>

      <v-col cols="12" sm="4">
        <v-card>
          <v-card-title>Maruti Swift</v-card-title>
          <v-card-text class="text-center">
            <v-img :src="marutiSwift" alt="Maruti Swift" height="150px" cover></v-img>
          </v-card-text>
          <v-card-actions class="d-flex flex-column">
            <div id="maruti_swift" class="d-flex gap-2">
              <v-btn @click="addCarStock($event, 1)" color="primary" size="small">+1</v-btn>
              <v-btn @click="addCarStock($event, 5)" color="primary" size="small">+5</v-btn>
              <v-btn @click="addCarStock($event, -1)" color="error" size="small">-1</v-btn>
            </div>
            <p class="mt-2">Total Sold: {{ maruti_swift }}</p>
          </v-card-actions>
        </v-card>
      </v-col>
    </v-row>
    <v-row v-align ="stretch">
  <!-- Luxury Car Card -->
  <v-col cols="12" md="6" class="h-100">
    <v-card class="h-100" variant="tonal">
      <v-card-title>Luxury Car</v-card-title>
      <v-card-subtitle>Luxury Car Category</v-card-subtitle>
      <v-card-text>
        Luxury cars are high-end vehicles that offer superior comfort, advanced technology, refined
        performance, and exceptional craftsmanship. Designed with premium materials and
        cutting-edge features, they often include plush interiors, powerful engines,
        state-of-the-art infotainment systems, and advanced safety technologies.
      </v-card-text>
    </v-card>
  </v-col>

  <!-- Sports Car Card -->
  <v-col cols="12" md="6" class="h-100">
    <v-card class="h-100" variant="tonal">
      <v-card-title>Sports Car</v-card-title>
      <v-card-subtitle>Sports Car Category</v-card-subtitle>
      <v-card-text>
        Sports cars are high-performance vehicles designed for speed, agility, and an exhilarating
        driving experience. Characterized by sleek aerodynamics, powerful engines, and precision
        handling, they are built to deliver both excitement and control on the road or track.
      </v-card-text>
    </v-card>
  </v-col>
</v-row>

 <v-container class="mt-3" fluid>
    <v-row justify="center" align="center" class="text-center">
      <v-col cols="12" sm="4" class="my-2">
        <v-btn @click="theme.toggle()" block color="primary">
          Toggle Light / Dark
        </v-btn>
      </v-col>

      <v-col cols="12" sm="4" class="my-2">
        <v-btn @click="theme.change('dark')" block color="secondary">
          Change to Dark
        </v-btn>
      </v-col>

      <v-col cols="12" sm="4" class="my-2">
        <v-btn @click="theme.cycle()" block color="success">
          Cycle All Themes
        </v-btn>
      </v-col>
    </v-row>
  </v-container>


  <div class="mt-3">
  <v-expansion-panels>
  <v-expansion-panel
    title="Title"
    text="Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi, ratione debitis quis est labore voluptatibus! Eaque cupiditate minima"
  >
  </v-expansion-panel>
</v-expansion-panels>
  </div>

<div class="mt-3">
      <v-carousel show-arrows="hover">
        <v-carousel-item
      src="https://images.unsplash.com/photo-1503376780353-7e6692767b70?auto=format&fit=crop&w=800&q=80"
          cover/>

        <v-carousel-item
      src="https://images.unsplash.com/photo-1525609004556-c46c7d6cf023?auto=format&fit=crop&w=800&q=80"
          cover/>
        <v-carousel-item
      src="https://images.unsplash.com/photo-1502877338535-766e1452684a?auto=format&fit=crop&w=800&q=80"
          cover/>
      </v-carousel>
</div>

  </v-container>


  <v-container>
    <v-row class="text-center">
      <v-col cols="12" md="6">
        <v-dialog max-width="340">
          <template v-slot:activator="{ props: activatorProps }">
            <v-btn
              v-bind="activatorProps"
              prepend-icon="mdi-package"
              width="204"
            >
              Sedan
            </v-btn>
          </template>

          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-package"
              text="When using the activator slot, you must bind the slot props to the activator element."
              title="Sedan Cars"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          prepend-icon="mdi-picture-in-picture-bottom-right"
          width="204"
        >
          Hatchback

          <v-dialog activator="parent" max-width="340">
            <template v-slot:default="{ isActive }">
              <v-card
                prepend-icon="mdi-picture-in-picture-bottom-right"
                text="When using the parent as the activator, the dialog will bind its listeners to the parent element."
                title="Hatchback Cars"
              >
                <template v-slot:actions>
                  <v-btn
                    class="ml-auto"
                    text="Close"
                    @click="isActive.value = false"
                  ></v-btn>
                </template>
              </v-card>
            </template>
          </v-dialog>
        </v-btn>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          ref="btn"
          prepend-icon="mdi-variable"
          width="204"
        >
          Crossover
        </v-btn>

        <v-dialog :activator="btn" max-width="340">
          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-variable"
              text="When using a ref, the dialog will bind its listeners to the ref element. This works for any element and custom components."
              title="Crossover Cars"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>

      <v-col cols="12" md="6">
        <v-btn
          id="activator-target"
          prepend-icon="mdi-bullseye-arrow"
          width="204"
        >
          Roadster
        </v-btn>

        <v-dialog activator="#activator-target" max-width="340">
          <template v-slot:default="{ isActive }">
            <v-card
              prepend-icon="mdi-bullseye-arrow"
              text="Pass any valid querySelector to the activator prop to bind the dialog to the target element."
              title="Roadster Cars"
            >
              <template v-slot:actions>
                <v-btn
                  class="ml-auto"
                  text="Close"
                  @click="isActive.value = false"
                ></v-btn>
              </template>
            </v-card>
          </template>
        </v-dialog>
      </v-col>
    </v-row>
  </v-container>
    </div>


  <v-footer class="text-center d-flex flex-column ga-2 py-4" color="surface-light">
    <div class="d-flex ga-3">
      <v-btn
        v-for="item in social_media_icons"
        :key="item.icon"
        :icon="item.icon"
        :href="item.url"
        density="comfortable"
        variant="text"
      />
    </div>

    <v-divider class="my-2" thickness="2" width="50"></v-divider>

    <div class="text-caption font-weight-regular opacity-60">
      Phasellus feugiat arcu sapien, et iaculis ipsum elementum sit amet. Mauris cursus commodo interdum. Praesent ut risus eget metus luctus accumsan id ultrices nunc. Sed at orci sed massa consectetur dignissim a sit amet dui. Duis commodo vitae velit et faucibus. Morbi vehicula lacinia malesuada. Nulla placerat augue vel ipsum ultrices, cursus iaculis dui sollicitudin. Vestibulum eu ipsum vel diam elementum tempor vel ut orci. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus.
    </div>

    <v-divider></v-divider>

    <div>
      {{ new Date().getFullYear() }} — <strong>Prince</strong>
    </div>
  </v-footer>
</template>

<script setup>
import { ref } from 'vue'
import tataTiago from '@/assets/pics/tata_tiago.avif'
import miniCooper from '@/assets/pics/mini_cooper.avif'
import marutiSwift from '@/assets/pics/maruti_swift.jpg'
import { useTheme } from 'vuetify'
import bg_image1 from '@/assets/pics/bg_image1.avif'
import bg_image2 from '@/assets/pics/bg_image2.avif'


const theme = useTheme()


const tata_tiagos = ref(0)
const mini_cooper = ref(0)
const maruti_swift = ref(0)

function addCarStock(e, number) {
  const id = e.target.closest('div').id

  if (id === 'tata_tiago') {
    tata_tiagos.value += number
  } else if (id === 'mini_cooper') {
    mini_cooper.value += number
  } else if (id === 'maruti_swift') {
    maruti_swift.value += number
  }
}

const social_media_icons = [
  { icon: 'mdi-facebook', url: 'https://facebook.com/princeyadav' },
  { icon: 'mdi-twitter', url: 'https://twitter.com/princeyadav' },
  { icon: 'mdi-linkedin', url: 'https://linkedin.com/in/aniket-yadav-2233171b6' },
  { icon: 'mdi-instagram', url: 'https://instagram.com/prince._.yadav' },
]

const btn = ref(null)
const allCarTypes = ['Sports','Sedan','Hatchback','Roadster','Convertible','Crossover']


</script>

<style scoped>
.gap-2 {
  gap: 8px;
}



</style>
