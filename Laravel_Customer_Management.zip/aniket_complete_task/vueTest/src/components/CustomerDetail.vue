<template>
  <div v-if="user_response_success" class="container">
    <h2 class="text-center mb-4">Customer Details</h2>

    <div v-if="loading" class="d-flex justify-content-center align-items-center my-5">
      <div class="spinner-border text-primary" role="status" aria-label="Loading..."></div>
    </div>

    <div v-else-if="customer" class="card shadow-sm p-4">
      <div class="mb-4">
        <h3 class="fw-bold">
          <template v-if="isEditing">
            <input v-model="editableCustomer.name" class="form-control form-control-lg" placeholder="Customer Name" />
          </template>
          <template v-else>
            {{ customer.name }}
          </template>
        </h3>
      </div>

      <div class="row g-3 mb-4">
        <div class="col-md-6">
          <label class="form-label fw-semibold">Company</label>
          <template v-if="isEditing">
            <input v-model="editableCustomer.company" class="form-control" placeholder="Company" />
          </template>
          <template v-else>
            <p class="border rounded p-2 bg-light">{{ customer.company || '-' }}</p>
          </template>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Email</label>
          <template v-if="isEditing">
            <input v-model="editableCustomer.email" type="email" class="form-control" placeholder="Email" />
          </template>
          <template v-else>
            <p class="border rounded p-2 bg-light">{{ customer.email || '-' }}</p>
          </template>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Phone</label>
          <template v-if="isEditing">
            <input v-model="editableCustomer.mobile" class="form-control" placeholder="Phone Number" />
          </template>
          <template v-else>
            <p class="border rounded p-2 bg-light">{{ customer.mobile || '-' }}</p>
          </template>
        </div>
        <div class="col-md-6">
          <label class="form-label fw-semibold">Address</label>
          <template v-if="isEditing">
            <textarea v-model="editableCustomer.address" rows="2" class="form-control" placeholder="Address"></textarea>
          </template>
          <template v-else>
            <p class="border rounded p-2 bg-light mb-0">{{ customer.address || '-' }}</p>
          </template>
        </div>
      </div>

      <div class="mb-4">
        <h4 class="mb-3 border-bottom pb-2">Contact Persons</h4>
        <div v-if="customer.contact_person && customer.contact_person.length" class="list-group">
          <div
            v-for="(contact, index) in (isEditing ? editableCustomer.contact_person : customer.contact_person)"
            :key="index"
            class="list-group-item list-group-item-action d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center"
          >
            <div class="flex-grow-1">
              <div class="d-flex align-items-center mb-2">
                <template v-if="isEditing">
                  <input
                    v-model="editableCustomer.contact_person[index].name"
                    class="form-control form-control-sm me-3"
                    placeholder="Name"
                  />
                </template>
                <template v-else>
                  <h5 class="mb-0">{{ contact.name }}</h5>
                </template>

                <span v-if="contact.isPrimary" class="badge bg-primary ms-2 me-3">Primary</span>
              </div>

              <div class="row g-2">
                <div class="col-md-4">
                  <label class="form-label small mb-1">Designation</label>
                  <template v-if="isEditing">
                    <input
                      v-model="editableCustomer.contact_person[index].designation"
                      class="form-control form-control-sm"
                      placeholder="Designation"
                    />
                  </template>
                  <template v-else>
                    <p class="mb-0">{{ contact.designation || '-' }}</p>
                  </template>
                </div>
                <div class="col-md-4">
                  <label class="form-label small mb-1">Email</label>
                  <template v-if="isEditing">
                    <input
                      v-model="editableCustomer.contact_person[index].email"
                      class="form-control form-control-sm"
                      placeholder="Email"
                    />
                  </template>
                  <template v-else>
                    <p class="mb-0">{{ contact.email || '-' }}</p>
                  </template>
                </div>
                <div class="col-md-4">
                  <label class="form-label small mb-1">Phone</label>
                  <template v-if="isEditing">
                    <input
                      v-model="editableCustomer.contact_person[index].mobile"
                      class="form-control form-control-sm"
                      placeholder="Phone"
                    />
                  </template>
                  <template v-else>
                    <p class="mb-0">{{ contact.mobile || '-' }}</p>
                  </template>
                </div>
              </div>
            </div>

            <div v-if="isEditing" class="mt-3 mt-md-0 ms-md-3 d-flex flex-column gap-2 align-items-start">
              <button
                type="button"
                class="btn btn-sm btn-outline-danger"
                @click="removeContactPerson(index)"
                title="Remove Contact Person"
              >
                <i class="bi bi-trash"></i> Remove
              </button>

              <button
                type="button"
                class="btn btn-sm btn-outline-primary"
                :disabled="editableCustomer.contact_person[index].isPrimary"
                @click="setPrimaryContact(index)"
                title="Set as Primary"
              >
                <i class="bi bi-star"></i> Primary
              </button>
            </div>
          </div>
        </div>
        <div v-else>
          <p class="text-muted fst-italic">No contacts available.</p>
        </div>
      </div>

      <div class="d-flex gap-2 flex-wrap">
        <button v-if="button_to_show && !isEditing" class="btn btn-warning" @click="startEditing">
          <i class="bi bi-pencil-square me-1"></i> Edit
        </button>

        <template v-else-if="button_to_show && isEditing">
          <button class="btn btn-info" @click="addMoreContactPerson">
            <i class="bi bi-plus-circle me-1"></i> Add Contact Person
          </button>
          <button class="btn btn-success" @click="saveChanges">
            <i class="bi bi-check-lg me-1"></i> Save
          </button>
          <button class="btn btn-secondary" @click="discardChanges">
            <i class="bi bi-x-lg me-1"></i> Discard
          </button>
        </template>
      </div>
    </div>

    <div v-else class="alert alert-danger text-center mt-5">
      Unable to load customer data.
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue';
import { useRoute } from 'vue-router';
import axios from 'axios';
import axiosClient from '@/axios/axiosClient'

const route = useRoute();
const customerId = route.params.id;
const user_response_success = ref(false);

const customer = ref(null);
const editableCustomer = ref(null);
const loading = ref(true);
const isEditing = ref(false);
const from_editCustomer = ref(route.query.from === 'editCustomer');
const button_to_show = from_editCustomer.value;

onMounted(async () => {
  try {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;
    user_response_success.value = false;

    if (!token) {
      throw new Error('No authorization token found');
    }
    const res = await axiosClient.get(`customer/${customerId}`);


    customer.value = res.data;
    user_response_success.value = true;
  } catch (error) {
    console.error('Failed to load customer data:', error);
  } finally {
    loading.value = false;
  }
});

const startEditing = () => {
  isEditing.value = true;
  editableCustomer.value = JSON.parse(JSON.stringify(customer.value));
};

const discardChanges = () => {
  isEditing.value = false;
  editableCustomer.value = null;
};

const saveChanges = async () => {
  try {
    loading.value = true;

    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;

    if (!token) {
      throw new Error('No authorization token found');
    }

    const payload = {
      name: editableCustomer.value.name,
      email: editableCustomer.value.email,
      mobile: editableCustomer.value.mobile,
      address: editableCustomer.value.address,
      company: editableCustomer.value.company,

      contactPerson: editableCustomer.value.contact_person.map((c) => ({
        id: c.id ?? null,
        name: c.name,
        email: c.email,
        mobile: c.mobile,
        designation: c.designation,
        isPrimary: c.isPrimary || false,
      })),
    };
    await axiosClient.put(`customer/${customerId}`, payload);
    alert('Customer updated successfully.');
    customer.value = JSON.parse(JSON.stringify(editableCustomer.value));
    isEditing.value = false;
  } catch (error) {
    console.error('Failed to save changes:', error);
    alert('Failed to save changes. Please try again.');
  } finally {
    loading.value = false;
  }
};

const addMoreContactPerson = () => {
  if (!editableCustomer.value.contact_person) {
    editableCustomer.value.contact_person = [];
  }
  editableCustomer.value.contact_person.push({
    id:'',
    name: '',
    designation: '',
    email: '',
    mobile: '',
    isPrimary: false,
  });
};

const removeContactPerson = (index) => {
  if (confirm('Are you sure you want to remove this contact person?')) {
    editableCustomer.value.contact_person.splice(index, 1);
  }
};

const setPrimaryContact = (index) => {
  editableCustomer.value.contact_person.forEach((c, i) => {
    c.isPrimary = i === index;
  });
};
</script>

<style scoped>
@media (max-width: 576px) {
  .list-group-item .btn {
    width: 100%;
  }
}
</style>
