<template>
    <v-navigation-drawer v-model="sidebar" app temporary>
      <v-list>
        <v-list-item
          v-for="item in filteredMenuItems"
          :key="item.title"
          :to="item.path"
          link
        >
          <v-list-item-icon>
            <v-icon>{{ item.icon }}</v-icon>
          </v-list-item-icon>
          <v-list-item-title>{{ item.title }}</v-list-item-title>
        </v-list-item>
      </v-list>
    </v-navigation-drawer>

    <v-app-bar app>
      <v-btn icon class="d-sm-none" @click="sidebar = !sidebar">
        <v-icon>mdi-menu</v-icon>
      </v-btn>

      <v-toolbar-title>
        <router-link to="/" style="text-decoration: none; color: inherit; cursor: pointer">
          {{ appTitle }}
        </router-link>
      </v-toolbar-title>

      <v-spacer />

      <div class="d-none d-sm-flex">
        <v-btn
          v-for="item in filteredMenuItems"
          :key="item.title"
          :to="item.path"
          variant="text"
        >
          <v-icon start>{{ item.icon }}</v-icon>
          {{ item.title }}
        </v-btn>
      </div>
    </v-app-bar>

</template>

<script>
import { mapGetters } from 'vuex'


export default {
  name: 'Navbar',
  data() {
    return {
      appTitle: 'Home',
      sidebar: false,
      storedUser: false,
    }
  },
  computed: {

        ...mapGetters({
            filteredMenuItems : 'hasAdd'
        }),
    
  },
}
</script>

<style>
a {
  text-decoration: none;
  color: inherit;
}
</style>
