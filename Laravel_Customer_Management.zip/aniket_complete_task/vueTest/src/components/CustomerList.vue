<template>
      <div class="modal fade show" style="display: block;" v-if="showDialog">
      <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header bg-danger text-white">
            <h5 class="modal-title">Server Error</h5>
          </div>
          <div class="modal-body">
            <p>Something went wrong. Please try again later.</p>
          </div>
        </div>
      </div>
    </div>
  <div v-if="user_response_success" class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h1 class="mb-0">Customer List</h1>
      <button class="btn btn-primary" @click="addCustomer">
        <i class="bi bi-plus-lg me-1"></i> Add Customer
      </button>
    </div>

    <div v-if="loading" class="text-center my-5">
      <div class="spinner-border text-primary" role="status"></div>
    </div>

    <div v-else>
      <div class="row mb-3">
        <div class="col-md-3">
          <input v-model="searchName" type="text" class="form-control" placeholder="Filter by Name" />
        </div>
        <div class="col-md-3">
          <input v-model="searchEmail" type="text" class="form-control" placeholder="Filter by Email" />
        </div>
        <div class="col-md-3">
          <input v-model="searchMobile" type="text" class="form-control" placeholder="Filter by Mobile" />
        </div>
        <div class="col-md-3">
          <button class="btn btn-secondary w-100" @click="handleSearch">
            <i class="bi bi-search me-1"></i> Search
          </button>
        </div>
      </div>

          <div class="d-flex justify-content-end align-items-center gap-4 mb-3 flex-nowrap">

  <div class="d-flex align-items-center gap-2" style="white-space: nowrap;">
    <label class="form-label mb-0 small" style="white-space: nowrap;">
      Records per page:
    </label>
    <select
      v-model.number="itemsPerPage"
      class="form-select form-select-sm"
      style="min-width: 80px;"
      @change="handleSearch"
    >
      <option v-for="option in perPageOptions" :key="option" :value="option">
        {{ option }}
      </option>
    </select>
  </div>

  <div class="d-flex align-items-center gap-2" style="white-space: nowrap;">
    <label class="form-label mb-0 small" style="white-space: nowrap;">
      Jump to page:
    </label>
    <div class="input-group input-group-sm" style="width: 120px;">
      <input
        type="number"
        min="1"
        :max="lastPage"
        v-model.number="jumpToPageNumber"
        class="form-control"
      />
      <button
        class="btn btn-outline-secondary"
        @click="jumpToPage"
        :disabled="jumpToPageNumber < 1 || jumpToPageNumber > lastPage"
      >
        Go
      </button>
    </div>
  </div>

</div>



<div class="table_div"  v-if="paginatedCustomers.length">


      <table class="table table-striped">
        <thead>
          <tr>
            <th>Name</th>
            <th>Company</th>
            <th>Email</th>
            <th>Phone</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="customer in paginatedCustomers" :key="customer.id">
            <td>{{ customer.name }}</td>
            <td>{{ customer.company }}</td>
            <td>{{ customer.email }}</td>
            <td>{{ customer.mobile }}</td>
            <td>
              <button class="btn btn-sm btn-outline-primary me-1" @click="viewCustomer(customer.id)">
                <i class="bi bi-eye"></i> View
              </button>
              <button class="btn btn-sm btn-outline-success me-1" @click="editCustomer(customer.id)">
                <i class="bi bi-pencil"></i> Edit
              </button>
              <button class="btn btn-sm btn-outline-danger" @click="deleteCustomer(customer.id)">
                <i class="bi bi-trash"></i> Delete
              </button>
            </td>
          </tr>
        </tbody>
      </table>
         <nav v-if="totalPages > 1">
        <ul class="pagination justify-content-center">
          <li class="page-item" :class="{ disabled: currentPage === 1 }">
            <a class="page-link" href="#" @click.prevent="goToPreviousPage">Previous</a>
          </li>
          <li
            v-for="page in totalPages"
            :key="page"
            class="page-item"
            :class="{ active: currentPage === page }"
          >
            <a class="page-link" href="#" @click.prevent="goToPage(page)">{{ page }}</a>
          </li>
          <li class="page-item" :class="{ disabled: currentPage === totalPages }">
            <a class="page-link" href="#" @click.prevent="goToNextPage">Next</a>
          </li>
        </ul>
      </nav>
      </div>
        <div v-else class="text-center py-5 text-muted">
    <i class="bi bi-info-circle me-2"></i> No records found.
  </div>

   
    </div>
  </div>
</template>

<script setup>
import { ref, computed, onMounted, watch } from 'vue';
import { useRouter } from 'vue-router';
import axios from 'axios';
import axiosClient from '@/axios/axiosClient';
import { useStore } from 'vuex';
const store = useStore();
const router = useRouter();
 const showDialog = ref(false); 

const customers = ref([]);
const loading = ref(true);
const currentPage = ref(1);
const itemsPerPage = ref(10);
const jumpToPageNumber = ref(1);
const totalItems = ref(0);
const lastPage = ref(1);

const searchName = ref('');
const searchEmail = ref('');
const searchMobile = ref('');

const perPageOptions = [2, 5, 10, 20, 50, 100];
const user_response_success = ref(false);

const fetchCustomers = async (page = 1) => {
  loading.value = true;
  // user_response_success.value = false;

  try {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;

    const response = await axiosClient.get('/customer', {
      params: {
        page,
        limit: itemsPerPage.value,
        ...(searchName.value && { name: searchName.value }),
        ...(searchEmail.value && { email: searchEmail.value }),
        ...(searchMobile.value && { mobile: searchMobile.value }),
      },
    });

    const data = response.data;
    customers.value = data.data;
    currentPage.value = data.page;
    lastPage.value = data.last_page;
    totalItems.value = data.total;
    jumpToPageNumber.value = data.page;
    user_response_success.value = true;
  } catch (error) {
     if (error.response && error.response.status === 500) {
        showDialog.value = true;
         setTimeout(() => {
           showDialog.value = false;
            router.push('/design');
          }, 3000);
    }

    console.error('Error fetching customers:', error);
    
  } finally {
    loading.value = false;
  }
};

onMounted(() => fetchCustomers(currentPage.value));

const totalPages = computed(() => lastPage.value);
const paginatedCustomers = computed(() => customers.value);

const handleSearch = () => {
  currentPage.value = 1;
  jumpToPageNumber.value = 1;
  fetchCustomers(1);
};

const goToPage = (page) => {
  if (page >= 1 && page <= totalPages.value) {
    currentPage.value = page;
    jumpToPageNumber.value = page;
    fetchCustomers(page);
  }
};

const goToPreviousPage = () => {
  if (currentPage.value > 1) {
    goToPage(currentPage.value - 1);
  }
};

const goToNextPage = () => {
  if (currentPage.value < totalPages.value) {
    goToPage(currentPage.value + 1);
  }
};

const jumpToPage = () => {
  if (jumpToPageNumber.value >= 1 && jumpToPageNumber.value <= totalPages.value) {
    goToPage(jumpToPageNumber.value);
  } else {
    alert(`Please enter a valid page between 1 and ${totalPages.value}`);
  }
};

watch(itemsPerPage, (newLimit) => {
  currentPage.value = 1;
  jumpToPageNumber.value = 1;
  fetchCustomers(1);
});

const addCustomer = () => router.push('/customerForm');

const viewCustomer = (id) => {
  router.push({
    path: `/customerDetails/${id}`,
    query: { from: 'viewCustomer' },
  });
};

const editCustomer = (id) => {
  router.push({
    path: `/customerDetails/${id}`,
    query: { from: 'editCustomer' },
  });
};

const deleteCustomer = async (id) => {
  if (!confirm('Are you sure you want to delete this customer?')) return;

  try {
    const user = JSON.parse(localStorage.getItem('user'));
    const token = user?.token;
    await axiosClient.delete(`/customer/${id}`);
    customers.value = customers.value.filter((c) => c.id !== id);
    alert('Customer deleted successfully.');
    fetchCustomers(currentPage.value);
  } catch (e) {
    alert('Failed to delete customer. Please try again.');
  }
};
</script>

<style scoped>
.table th,
.table td {
  vertical-align: middle;
}

@media (max-width: 768px) {
  .table_div {
    overflow-x: auto !important;
    -webkit-overflow-scrolling: touch;
  }
}
</style>