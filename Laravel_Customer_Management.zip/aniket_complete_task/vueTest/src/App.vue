<template>
  <v-app>
    test From App.vue
    <v-main>
      <navbar/>
      <router-view />
    </v-main>
  </v-app>
</template>

<script lang="ts" setup>
  //
</script>
