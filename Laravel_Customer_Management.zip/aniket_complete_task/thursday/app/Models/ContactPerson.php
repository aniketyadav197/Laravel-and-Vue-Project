<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ContactPerson extends Model
{
    use HasFactory;
    
    protected $table = 'contactpersons'; 
    protected $fillable = ['customer_id', 'name', 'email', 'mobile', 'designation','isPrimary'];

    public function customer()
    {
        return $this->belongsTo(Customer::class);
    }
}
