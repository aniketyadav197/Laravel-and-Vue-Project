<?php

namespace App\Http\Controllers;
use App\Models\Customer;
use App\Models\ContactPerson;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB; 

class CustomerController extends Controller
{
    
    public function index(Request $request)
{
    try {
        $query = Customer::query();

        if ($request->filled('name')) {
            $query->where('name', 'like', '%' . $request->name . '%');
        }

        if ($request->filled('email')) {
            $query->where('email', 'like', '%' . $request->email . '%');
        }

        if ($request->filled('mobile')) {
            $query->where('mobile', 'like', '%' . $request->mobile . '%');
        }
     $limit = $request->has('limit') ? $request->limit : 100;
        $page = max((int) $request->input('page', 1), 1);
        $offset = ($page - 1) * $limit;

        $total = $query->count();

        $customers = $query->skip($offset)->take($limit)->get();

        return response()->json([
            'data' => $customers,
            'page' => $page,
            'limit' => $limit,
            'total' => $total,
            'last_page' => ceil($total / $limit),
        ]);
    } catch (\Exception $e) {
        return response()->json(['error' => $e->getMessage()], 500);
    }
}



public function store(Request $request)
{
    try {
        $validated = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:customers,email',
            'mobile' => 'required|string|unique:customers,mobile',
            'address' => 'required|string',
            'country' => 'nullable|string',
            'company' => 'nullable|string',
            'contactPerson' => 'required|array|min:1',
            'contactPerson.*.name' => 'required|string',
            'contactPerson.*.email' => 'required|email|unique:contactpersons,email',
            'contactPerson.*.mobile' => 'required|string|unique:contactpersons,mobile',
            'contactPerson.*.designation' => 'required|string',
            'contactPerson.*.isPrimary' => 'nullable|boolean',
        ]);

        $primaryContacts = collect($validated['contactPerson'])->filter(function ($contact) {
            return !empty($contact['isPrimary']);
        });

        if ($primaryContacts->count() > 1) {
            return response()->json([
                'error' => 'Only one contact person can be marked as primary.'
            ], 422);
        }

        DB::beginTransaction();

        $customerData = $request->only(['name', 'email', 'mobile', 'address', 'country','company']);
        $customer = Customer::create($customerData);

        foreach ($validated['contactPerson'] as $contact) {
            $contact['isPrimary'] = !empty($contact['isPrimary']) ? 1 : 0;
            $customer->contactPerson()->create($contact);
        }

        DB::commit();

        return response()->json($customer->load('contactPerson'), 201);
    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json(['error' => $e->getMessage()], 500);
    }
}



public function show_customer_record_from_id(Request $data) {
    try {
       $coming_id =  $data->id;
        $customer = Customer::with('contactPerson')->findorFail($coming_id);
        return response()->json( $customer);
    }
    catch (\Exception $e) {
            return response()->json(['error' => 'Customer not found'], 404);
        }
}

public function update_customer_record(Request $request)
{
    try {
        $customer_id = $request->id;

        $customer = Customer::with('contactPerson')->findOrFail($customer_id);

        $validated = $request->validate([
            'name' => 'required|string',
            'email' => 'required|email|unique:customers,email,' . $customer->id,
            'mobile' => 'required|string|unique:customers,mobile,' . $customer->id,
            'address' => 'required|string',
            'country' => 'nullable|string',
            'company' => 'nullable|string',
            'contactPerson' => 'required|array|min:1',
            'contactPerson.*.name' => 'required|string',
            'contactPerson.*.email' => 'required|email',
            'contactPerson.*.mobile' => 'required|string',
            'contactPerson.*.designation' => 'required|string',
            'contactPerson.*.isPrimary' => 'nullable|boolean',
            'contactPerson.*.id' => 'nullable|integer|exists:contactpersons,id',
        ]);

        $primaryContacts = collect($validated['contactPerson'])->filter(function ($contact) {
            return !empty($contact['isPrimary']);
        });

        if ($primaryContacts->count() > 1) {
            return response()->json([
                'error' => 'Only one contact person can be marked as primary.'
            ], 422);
        }

        DB::beginTransaction();

        $customer->update($request->only(['name', 'email', 'mobile', 'address', 'country','company']));

        $existingContactIds = $customer->contactPerson->pluck('id')->toArray();
        $incomingContactIds = collect($validated['contactPerson'])->pluck('id')->filter()->toArray();

        $contactsToDelete = array_diff($existingContactIds, $incomingContactIds);
        if (!empty($contactsToDelete)) {
            $customer->contactPerson()->whereIn('id', $contactsToDelete)->delete();
        }

        $customer->contactPerson()->update(['isPrimary' => 0]);

        foreach ($validated['contactPerson'] as $contactData) {
            $contactData['isPrimary'] = !empty($contactData['isPrimary']) ? 1 : 0;

            if (isset($contactData['id'])) {
                $contact = $customer->contactPerson()->where('id', $contactData['id'])->first();
                if ($contact) {
                    $contact->update($contactData);
                }
            } else {
                $customer->contactPerson()->create($contactData);
            }
        }

        DB::commit();

        return response()->json($customer->load('contactPerson'), 200);

    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json(['error' => $e->getMessage()], 500);
    }
}


public function detete_customer_record(Request $response){

    try {
            $customer_id = $response->id;
            $customer = Customer::findorFail($customer_id);
            $customer->delete();
            return response()->json(['message' => 'Customer deleted']);
    } catch (\Exception $e) {
            return response()->json(['error' => $e->getMessage()], 500);
    }



}



}
