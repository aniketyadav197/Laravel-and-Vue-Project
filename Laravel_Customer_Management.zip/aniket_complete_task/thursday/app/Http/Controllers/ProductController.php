<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Category;
use Illuminate\Database\Eloquent\ModelNotFoundException;


class ProductController extends Controller{

    public function index(Request $request){
        try {
            $query = Product::query('category');

            if ($request->has('status')) {
                $query->where('status', $request->status);
            }

            if ($request->has('search')) {
                $query->where('name', 'like', '%' . $request->search . '%');
            }
            if ($request->has('category_name')) {
                $query->whereHas('category', function ($q) use ($request) {
                    $q->where('name', 'like', '%' . $request->category_name . '%');
                });
            }
            $limit = $request->has('limit') ? (int) $request->limit : 100;
            $page = max((int) $request->input('page', 1), 1);
            $offset = ($page - 1) * $limit;

            $total = $query->count();
            $products = $query->skip($offset)->take($limit)->get();

            return response()->json([
                'data' => $products,
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'last_page' => ceil($total / $limit),
            ],200);
        } catch (\Exception $e) {
            return response()->json([
                'error' => 'Something went wrong',
                'message' => $e->getMessage()
            ], 500);
        }
    }


    public function show($id)
    {
        try{
            $product = Product::with('category')->find($id);
            if (!$product) {
                return response()->json(['message' => 'Product not found'], 404);
            }
            return response()->json($product, 200);
        }
        catch(\Exception $e){
            return response()->json([
                'message' => 'Something went wrong',
                'error' => $e->getMessage()
            ],500);
        }

    }

    public function store(Request $request){
        try {
            

            $request->validate([
                'name'        => 'required|string',
                'category_id' => 'required|exists:categories,id',
                'description' => 'nullable|string',
                'price'       => 'required|numeric|min:0',
                'quantity'    => 'required|integer|min:0',
                'status'      => 'in:active,inactive',
            ]);
            $product = Product::create($request->all());

            return response()->json(['message' => 'Product created', 'data' => $product], 201);
        } 
        catch (\Exception $e) {
            return response()->json(['message' => 'Something went wrong', 'error' => $e->getMessage()], 500);
        }
    }


    public function update(Request $request, $id)
    {
        try{
            $product = Product::find($id);

            if (!$product) {
                return response()->json(['message' => 'Product not found'], 404);
            }

            $request->validate([
                'name'        => 'sometimes|string',
                'category_id' => 'sometimes|exists:categories,id',
                'description' => 'nullable|string',
                'price'       => 'sometimes|numeric|min:0',
                'quantity'    => 'sometimes|integer|min:0',
                'status'      => 'in:active,inactive',
            ]);

            $product->update($request->all());

            return response()->json(['message' => 'Product updated', 'data' => $product], 200);
        }catch (\Exception $e) {
            return response()->json([
                'message' => 'An unexpected error occurred',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function destroy($id)
    {
        try{
            $product = Product::find($id);
            if (!$product) {
                return response()->json(['message' => 'Product not found'], 404);
            }
            $product->delete();
            return response()->json(['message' => 'Product deleted'], 200);
        }
         catch (\Exception $e) {
            return response()->json([
                'message' => 'An unexpected error occurred',
                'error' => $e->getMessage()
            ], 500);
        }
    
    }
}
