<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Category;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        try{

            $query = Category::query();
            if($request->has('name')){
                $query->where('name', $request->name);
            }
            $limit = $request->has('limit') ? (int) $request->limit : 100;
            $page = max((int) $request->input('page', 1), 1);
            $offset = ($page - 1) * $limit;
            $total = $query->count();
            $all_categories = $query->skip($offset)->take($limit)->get();
            return response()->json([
                'data' => $all_categories,
                'page' => $page,
                'limit' => $limit,
                'total' => $total,
                'last_page' => ceil($total / $limit),
            ]);
        }
        catch(\Exception $e){
            return response()->json([
                'message' => 'An error occur while retrieving data',
                'error' => $e->getMessage(),
            ],500);
        }
    }

    public function store(Request $request)
    {
        try{
            $request->validate([
                'name' => 'required|string|unique:categories,name'
            ]);
            $category = Category::create(['name' => $request->name]);
            return response()->json(['message' => 'Category created', 'data' => $category], 201);
        }
        catch(\Exception $e){
          return response()->json([
            'message' => 'An error occured while adding category',
            'error' => $e->getMessage(),
          ],500);
        }
      
    }
    public function show($id){
        try {
            $category = Category::find($id);
            if (!$category) {
                return response()->json(['message' => 'Category not found'], 404);
            }
            return response()->json($category, 200);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'Something went wrong',
                'error' => $e->getMessage()
            ], 500);
        }
    }

    public function update(Request $request, $id)
    {
        try{
            $category = Category::find($id);
            if (!$category) {
                return response()->json(['message' => 'Category not found'], 404);
            }
            $request->validate(['name' => 'required|string|unique:categories,name,' . $id]);
            $category->update(['name' => $request->name]);
            return response()->json(['message' => 'Category updated', 'data' => $category], 200);
        }
        catch(\Exception $e){
            return response()->json([
                'message' => 'An error occured while updating model category',
                'error' => $e->getMessage(),
            ],500);
        }
     
    }

    public function destroy(Request $request){
        try {
            $category = Category::find($request->id);
            if (!$category) {
                return response()->json(['message' => 'Category not found'], 404);
            }
            $category->delete();
            return response()->json(['message' => 'Category deleted'], 200);
        } catch (\Exception $e) {
            return response()->json([
                'message' => 'An error occurred while deleting the category',
                'error' => $e->getMessage(),
            ], 500);
        }
    }

}
