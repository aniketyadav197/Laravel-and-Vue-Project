<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure(\Illuminate\Http\Request): (\Illuminate\Http\Response|\Illuminate\Http\RedirectResponse)  $next
     * @return \Illuminate\Http\Response|\Illuminate\Http\RedirectResponse
     */

    public function handle(Request $request, Closure $next){

          try {
            $user = JWTAuth::parseToken()->authenticate();

            if (!auth()->check()) {
                return response()->json(['error' => 'You must be logged in to access this resource.'], 401);
            }
            if (auth()->user()->role !== 'admin') {
                return response()->json(['error' => 'You are not authorized to access this resource.'], 403);
            }
            return $next($request);

        } catch (JWTException $e) {
            return response()->json(['error' => 'Token invalid or expired'], 401);
        }

    }

}
